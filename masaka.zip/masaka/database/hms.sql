-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2021 at 10:08 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'admin', '24-06-2021 11:46:33 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `reason` varchar(50) NOT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `reason`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(6, 'Dentist', 10, 8, 50000, '', '2021-07-31', '12:00 PM', '2021-07-08 08:55:31', 1, 0, '2021-07-09 18:54:40'),
(7, 'Surgeon', 12, 10, 15000, '', '2021-07-31', '3:45 PM', '2021-07-08 12:34:31', 1, 0, '2021-07-08 13:20:31'),
(8, 'Eyes', 11, 10, 10000, 'My daughter has an eye problem', '2021-07-17', '4:15 PM', '2021-07-08 13:02:55', 1, 1, NULL),
(9, 'Dentist', 10, 11, 50000, 'Tooth pain', '2021-07-10', '9:45 AM', '2021-07-09 18:32:13', 1, 1, NULL),
(10, 'gynaecologist', 13, 12, 10000, 'antenatal', '2021-07-14', '9:45 AM', '2021-07-10 11:38:07', 1, 0, '2021-07-10 11:39:05'),
(11, 'Dentist', 10, 12, 20000, 'Pain', '2021-07-15', '11:00 AM', '2021-07-12 08:01:33', 1, 1, NULL),
(12, 'Surgeon', 12, 12, 15000, 'Leg', '2021-07-22', '11:15 AM', '2021-07-12 08:04:46', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `period` varchar(100) NOT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `period`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(10, 'Dentist', 'Ndugga Vianne', 'Masaka', 'Tuesday to Thursday from 9:00am to 4:00pm', '20000', 758197081, 'viane@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-06 15:58:15', '2021-07-12 05:07:06'),
(11, 'Eyes', 'Madam Madinah', 'Kyotera', 'Monday to Tuesday from 9:00am to 4:00pm', '10000', 758197081, 'madinah@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-06 16:06:15', '2021-07-12 05:09:58'),
(12, 'Surgeon', 'Shamirah', 'Masaka', 'Wednesday to Friday from 9:00am to 4:00pm', '15000', 758197081, 'shamirah@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-08 11:59:48', '2021-07-12 05:12:21'),
(13, 'gynaecologist', 'Ssenyondo B', 'Masaka', 'Friday from 9:00am to 4:00pm', '10000', 7895678, 'ssenyondo@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-10 11:05:16', '2021-07-12 05:12:43');

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(27, 11, 'madinah@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-06 17:34:27', '06-07-2021 11:04:43 PM', 1),
(28, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-06 17:36:00', '06-07-2021 11:06:27 PM', 1),
(37, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-08 08:30:34', '08-07-2021 02:01:00 PM', 1),
(41, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-08 08:42:41', '08-07-2021 02:12:45 PM', 1),
(42, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-08 08:57:54', '08-07-2021 02:32:36 PM', 1),
(49, 10, 'viane@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-08 12:26:33', '08-07-2021 05:56:40 PM', 1),
(51, 12, 'shamirah@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-08 12:27:04', '08-07-2021 06:01:37 PM', 1),
(52, 12, 'shamirah@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-08 12:35:24', '08-07-2021 06:06:51 PM', 1),
(53, 12, 'shamirah@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-08 12:38:46', '12-07-2021 01:08:33 PM', 1),
(54, 10, 'viane@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-08 13:19:47', '08-07-2021 06:49:56 PM', 1),
(55, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-09 18:08:27', '09-07-2021 11:58:53 PM', 1),
(56, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-09 18:38:02', NULL, 0),
(57, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-09 18:38:25', '10-07-2021 12:22:12 AM', 1),
(58, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-09 18:54:10', NULL, 1),
(59, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:21:23', '10-07-2021 03:54:18 PM', 1),
(60, NULL, 'ssenyondo', 0x3132372e302e302e3100000000000000, '2021-07-10 11:12:49', NULL, 0),
(61, 13, 'ssenyondo@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 11:13:10', '10-07-2021 05:02:47 PM', 1),
(62, 13, 'ssenyondo@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 11:38:42', '10-07-2021 05:09:09 PM', 1),
(63, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 17:17:48', NULL, 0),
(64, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 17:18:02', '10-07-2021 11:55:03 PM', 1),
(65, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:17:06', NULL, 0),
(66, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:17:20', '11-07-2021 12:53:45 AM', 1),
(67, 13, 'ssenyondo@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:24:31', '11-07-2021 12:57:26 AM', 1),
(68, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:52:10', NULL, 0),
(69, NULL, 'viane@gmail.om', 0x3132372e302e302e3100000000000000, '2021-07-10 19:52:24', NULL, 0),
(70, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:52:46', NULL, 0),
(71, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:53:03', '11-07-2021 01:24:26 AM', 1),
(72, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:54:36', NULL, 0),
(73, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:54:45', NULL, 0),
(74, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:54:55', '11-07-2021 01:25:11 AM', 1),
(75, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:55:23', NULL, 0),
(76, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:55:31', NULL, 0),
(77, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:55:45', NULL, 0),
(78, NULL, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 04:17:00', NULL, 0),
(79, NULL, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 04:17:22', NULL, 0),
(80, NULL, 'vianne@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 05:29:29', NULL, 0),
(81, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 05:29:47', NULL, 1),
(82, NULL, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 05:35:43', NULL, 0),
(83, 13, 'ssenyondo@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 05:36:28', '12-07-2021 11:10:02 AM', 1),
(84, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 07:31:01', NULL, 1),
(85, 10, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 08:05:33', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(13, 'Dentist', '2021-07-06 15:48:56', NULL),
(14, 'Optics', '2021-07-06 16:04:10', '2021-07-10 17:14:20'),
(15, 'Surgeon', '2021-07-08 11:51:55', NULL),
(16, 'Gynaecologist', '2021-07-10 11:02:18', '2021-07-12 04:14:13');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `AdminRemark` mediumtext,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(1, 'Walakira Derrick', 'walakira@gmailcom', 75678960, ' Doctors should respond to their appointments date', '2021-07-09 18:02:06', 'Doctors should followed up', '2021-07-09 18:03:29', 1),
(2, 'Nabakooza', 'nabakooza@gmail.com', 7568945, ' fffffffffffffffffffffffffffffffffffffjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', '2021-07-10 11:09:15', 'ok', '2021-07-10 11:09:51', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `Result` varchar(200) NOT NULL,
  `Diagnosis` varchar(200) NOT NULL,
  `MedicalPres` mediumtext,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `BloodPressure`, `Weight`, `Temperature`, `Result`, `Diagnosis`, `MedicalPres`, `CreationDate`) VALUES
(12, 6, '89', '67', '34', 'Positive', 'Sick', 'Tablets', '2021-07-10 18:19:53'),
(13, 10, '58', '80', '37', 'Positive', 'Malaria', 'Quantem', '2021-07-12 05:37:47');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(6, 10, 'Kasirivu Gerald', 75678901, 'kasirivu@gmail.com', 'Male', 'Masaka', 20, 'None', '2021-07-08 09:01:47', '2021-07-09 18:23:12'),
(7, 10, 'Kem Christ', 75891045, 'kem@gmail.com', 'Male', 'Masaka', 24, 'None', '2021-07-09 18:10:17', '2021-07-09 18:24:12'),
(8, 10, 'Mujjuzi Joshua', 75678998, 'mujjuzi@gmail.com', 'Male', 'Soweto', 25, 'High blood Pressure', '2021-07-09 18:48:42', '2021-07-09 18:51:09'),
(9, 10, 'Nalubega Jack', 756789458, 'jack@gmail.com', 'Male', 'masaka', 40, 'None', '2021-07-10 10:23:55', '2021-07-10 17:21:01'),
(10, 13, 'Lubowa Coney', 78956674, 'lubowa@gmail.com', 'Male', 'Masaka', 28, 'Haemophilia, high blood pressure', '2021-07-10 11:17:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 11, 'walakira@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-09 18:30:11', '10-07-2021 12:07:46 AM', 1),
(2, NULL, 'mujjuzi@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:24:55', NULL, 0),
(3, NULL, 'kem@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:25:21', NULL, 0),
(4, 8, 'kasirivu@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:25:53', NULL, 1),
(5, 8, 'kasirivu@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-10 10:32:37', NULL, 1),
(6, NULL, 'viane@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:47:16', NULL, 0),
(7, 8, 'kasirivu@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 10:47:58', '10-07-2021 04:27:00 PM', 1),
(8, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 11:35:28', '10-07-2021 05:08:25 PM', 1),
(9, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 11:39:24', '10-07-2021 05:13:30 PM', 1),
(10, NULL, 'lubowa@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 18:25:36', NULL, 0),
(11, NULL, 'lubowa@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 18:25:46', NULL, 0),
(12, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 18:26:23', '11-07-2021 12:19:47 AM', 1),
(13, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 18:51:25', NULL, 1),
(14, 12, 'nakato@gmail.com', 0x3a3a3100000000000000000000000000, '2021-07-10 18:56:16', '11-07-2021 12:46:41 AM', 1),
(15, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:27:56', '11-07-2021 01:18:23 AM', 1),
(16, 8, 'kasirivu@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-10 19:48:32', '11-07-2021 01:21:55 AM', 1),
(17, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 04:18:04', NULL, 1),
(18, 8, 'kasirivu@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 05:41:24', '12-07-2021 01:00:42 PM', 1),
(19, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 07:37:29', NULL, 1),
(20, 12, 'nakato@gmail.com', 0x3132372e302e302e3100000000000000, '2021-07-12 07:39:03', '12-07-2021 01:35:14 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(8, 'Kairuvu Gerald', 'Masaka', 'Masaka', 'male', 'kasirivu@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-08 08:48:07', NULL),
(9, 'Bayiga  Francis', 'Masaka', 'Masaka', 'female', 'bayiga@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-08 11:36:25', NULL),
(10, 'Serwada Joshua', 'Nyendo', 'Kampala', 'female', 'serwada@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-08 12:32:58', NULL),
(12, 'Nakato Mary', 'Kyotera', 'Kyotera', 'female', 'nakato@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-10 11:35:01', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
