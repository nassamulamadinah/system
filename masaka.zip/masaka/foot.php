<?php
/**
 * foot.php
 * Footer of each page
 */
?>
<style type="text/css">

#footer {
   color:#FF0000;
   position: fixed;
   bottom:0;
   width:100%;
   height:50px;   /* Height of the footer */
   background:yellow;
}

</style>

<br><br><br><br><br><br><br><br>
    <div id="footer">
      <center>nnnnnnnhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh</center></a>
    </div>

  </body>
</html>


